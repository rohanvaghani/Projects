package com.rv.parking;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.TextView;


public class Frag_receipt extends Fragment {

    @Override
    public void onViewCreated(View view,@Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        getActivity().setTitle("Parking Receipt");
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_frag_receipt, container, false);

        SharedPreferences sp = this.getActivity().getSharedPreferences("com.rv.parking.shared", Context.MODE_PRIVATE);

        String carplate = sp.getString("CarPlate","Data Missing");
        String carcompany = sp.getString("Company", "Data Missing");
        String payment = sp.getString("Payment", "Data Missing");
        String lot = sp.getString("Lot", "Data Missing");
        String spot = sp.getString("Spot", "Data Missing");
        String datetime = sp.getString("DateTime", "Data Missing");
        String amount = String.valueOf(sp.getInt("Amount", 0));

        TextView txtCarPlate = (TextView) rootView.findViewById(R.id.txtCarPlate);
        TextView txtCarCompany = (TextView) rootView.findViewById(R.id.txtCarCompany);
        TextView txtPaymentMode = (TextView) rootView.findViewById(R.id.txtPaymentMode);
        TextView txtLotNumber = (TextView) rootView.findViewById(R.id.txtLotNumber);
        TextView txtSpotNumber = (TextView) rootView.findViewById(R.id.txtSpotNumber);
        TextView txtDateTime = (TextView) rootView.findViewById(R.id.txtDateTime);
        TextView txtAmount = (TextView) rootView.findViewById(R.id.txtAmount);

        txtCarPlate.setText(carplate);
        txtCarCompany.setText(carcompany);
        txtPaymentMode.setText(payment);
        txtLotNumber.setText(lot);
        txtSpotNumber.setText(spot);
        txtDateTime.setText(datetime);
        txtAmount.setText("$ "+amount);

        return rootView;
    }


}
