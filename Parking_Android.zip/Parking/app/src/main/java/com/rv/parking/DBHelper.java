package com.rv.parking;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DBHelper extends SQLiteOpenHelper {

    private final static String DB_NAME = "ThunderDB";
    private final static String TB_NAME_USER = "UserInfo";
    private final static String TB_PARKING_DATA = "Parkings";

    public static String loggedUser = "";

    public static String getLoggedUser() {
        return loggedUser;
    }

    public static void setLoggedUser(String loggedUser) {
        DBHelper.loggedUser = loggedUser;
    }

    public DBHelper(Context context) {
        super(context, DB_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            String CREATE_TABLE = "CREATE TABLE " + TB_NAME_USER + " (Id INTEGER AUTO_INCREMENT," + "Name VARCHAR(100), Phone VARCHAR(30)," + "Email VARCHAR(100) PRIMARY KEY, Password VARCHAR(30)," + "CarPlate VARCHAR(20))";
            Log.v("On create table : ",CREATE_TABLE);
            db.execSQL(CREATE_TABLE);

            String CREATE_TABLE2 = " CREATE TABLE " + TB_PARKING_DATA + " (Id INTEGER AUTO_INCREMENT,"
                    + "userEmail VARCHAR(50),"
                    + "carPlate VARCHAR(100),"
                    + "carCompany VARCHAR(100),"
                    + "slot VARCHAR(5),"
                    + "lot VARCHAR(5),"
                    + "payment VARCHAR(20),"
                    + "dateTime VARCHAR(100),"
                    + "totalCost INTEGER)";


            Log.v("On create table : ",CREATE_TABLE2);
            db.execSQL(CREATE_TABLE2);
        }
        catch (Exception e) {
            Log.e("DBHelper",e.getMessage());
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        try {
            db.execSQL("DROP TABLE IF EXISTS " + TB_NAME_USER);
            db.execSQL("DROP TABLE IF EXISTS " + TB_PARKING_DATA);
            onCreate(db);
        }catch(Exception e) {
            Log.e("DBHelper",e.getMessage());
        }
    }
}

