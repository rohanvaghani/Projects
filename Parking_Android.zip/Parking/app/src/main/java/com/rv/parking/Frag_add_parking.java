package com.rv.parking;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;
import java.util.Date;

public class Frag_add_parking extends Fragment {

    RadioButton rdoHalf, rdoOne, rdoTwo, rdoThree;
    TextView txtAmount, txtDateTime;
    int parkingRate[] = {5,10,20,35};
    String lots[]={"A","B","C","D","E"};
    String spots[] = {"1","2","3","4","5"};
    String paymentMethods[] = {"Debit", "Visa", "Master", "American Express"};
    Button btnSave;
    EditText edtCarPlate;
    DBHelper dbHelper;
    SQLiteDatabase thunderDB;

    int logos[]={R.drawable.img_bmw,R.drawable.img_audi,
            R.drawable.img_mercedes,R.drawable.img_jaguar,
            R.drawable.img_lexus};
    String companyNames[]={"BMW","Audi","Marcedes","Jaguar","Lexus"};

    Spinner spinLot, spinSpot, spinPayment, spinCompany;

    String lot, spot, carPlate, payment, dateTime, company;
    int amount;

    @Override
    public void onViewCreated(View view,@Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        getActivity().setTitle("Add Parking Details");

        rdoHalf = (RadioButton) view.findViewById(R.id.rdoHalfHour);
        rdoHalf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtAmount.setText("$" + String.valueOf(parkingRate[0]));
            }
        });

        rdoOne = (RadioButton) view.findViewById(R.id.rdoOneHour);
        rdoOne.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtAmount.setText("$" + String.valueOf(parkingRate[1]));
            }
        });

        rdoTwo = (RadioButton)view.findViewById(R.id.rdoTwoHour);
        rdoTwo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtAmount.setText("$" + String.valueOf(parkingRate[2]));
            }
        });

        rdoThree = (RadioButton)view.findViewById(R.id.rdoThreeHour);
        rdoThree.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtAmount.setText("$" + String.valueOf(parkingRate[3]));
            }
        });

        btnSave = (Button) view.findViewById(R.id.btnSave);
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dateTime = txtDateTime.getText().toString();

                carPlate = edtCarPlate.getText().toString();
                String strAmount = txtAmount.getText().toString();
                strAmount = strAmount.substring(1);
                amount = Integer.parseInt(strAmount);

                /*SharedPreferences sp = getActivity().getSharedPreferences("com.rv.parking.shared", Context.MODE_PRIVATE);
                SharedPreferences.Editor edit = sp.edit();

                edit.putString("CarPlate",carPlate);
                edit.putString("Company",company);
                edit.putInt("Amount",amount);
                edit.putString("DateTime",dateTime);
                edit.putString("Lot",lot);
                edit.putString("Spot",spot);
                edit.putString("Payment",payment);
                edit.commit();*/


                try {
                    dbHelper = new DBHelper(getActivity().getApplicationContext());
                    thunderDB = dbHelper.getWritableDatabase();


                    ContentValues values = new ContentValues();

                    values.put("carPlate", carPlate);
                    TempValues.setCarPlate(carPlate);
                    values.put("userEmail", TempValues.currentLoggedUser);
                    values.put("carCompany", company.toString());
                    TempValues.setCarCompany(company.toString());
                    values.put("slot", spot);
                    TempValues.setSlot(spot);
                    values.put("lot", lot);
                    TempValues.setLot(lot);
                    values.put("payment", payment);
                    TempValues.setPayment(payment);
                    values.put("dateTime", dateTime);
                    TempValues.setDateTime(dateTime);
                    values.put("totalCost", strAmount.toString());
                    TempValues.setTotalCost(strAmount.toString());

                    thunderDB.insert("Parkings", null, values);
                }
                catch (Exception e) {
                    Log.e("Parkings",e.getMessage());
                }

                Toast.makeText(getActivity(), "CHECK YOUR RECEIPT!", Toast.LENGTH_SHORT).show();

                Intent reportIntent = new Intent(getActivity(),ReportActivity.class);
                startActivity(reportIntent);

                /*android.support.v4.app.Fragment fragment = null;
                fragment = new Frag_receipt();

                FragmentManager fragmentManager  = getActivity().getSupportFragmentManager();
                FragmentTransaction ft = fragmentManager.beginTransaction();
                ft.replace(R.id.screen_area,fragment);

                ft.commit()*/;
            }
        });

        txtAmount = (TextView) view.findViewById(R.id.txtAmount);
        txtAmount.setText("$" + String.valueOf(parkingRate[0]));
        edtCarPlate = (EditText) view.findViewById(R.id.etCarPlate);

        txtDateTime = (TextView) view.findViewById(R.id.txtDateTime);
        Date dt = Calendar.getInstance().getTime();
        txtDateTime.setText(dt.toString());

        spinLot = (Spinner) view.findViewById(R.id.spinLot);
        ArrayAdapter adaptLot = new ArrayAdapter(
                this.getActivity(),
                android.R.layout.simple_spinner_item,
                lots);
        adaptLot.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);
        spinLot.setAdapter(adaptLot);
        spinLot.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                lot = lots[position];
                }
             @Override
             public void onNothingSelected(AdapterView<?> parent) {

             }
             });

        spinSpot = (Spinner) view.findViewById(R.id.spinSpot);
        ArrayAdapter adaptSpot = new ArrayAdapter(
                this.getActivity(),
                android.R.layout.simple_spinner_item,
                spots);
        adaptSpot.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);
        spinSpot.setAdapter(adaptSpot);
        spinSpot.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                spot = spots[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spinPayment = (Spinner) view.findViewById(R.id.spinPayment);
        ArrayAdapter adaptPayment = new ArrayAdapter(
                this.getActivity(),
                android.R.layout.simple_spinner_item,
                paymentMethods);
        adaptPayment.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);
        spinPayment.setAdapter(adaptPayment);
        spinPayment.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                payment = paymentMethods[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spinCompany = (Spinner) view.findViewById(R.id.spinCompany);
        CarAdapter carAdapter = new CarAdapter(getActivity().getApplicationContext(),
                logos, companyNames);
        spinCompany.setAdapter(carAdapter);
        spinCompany.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                company = companyNames[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_frag_add_parking, container, false);

    }

}
