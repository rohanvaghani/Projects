package com.rv.parking;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.Editable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;


public class Frag_feedback extends Fragment {

    Button btnSubmit;
    EditText txtSubject, txtBody;

    @Override
    public void onViewCreated(View view,@Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        getActivity().setTitle("Feedback");
        txtSubject = (EditText) view.findViewById(R.id.txtSubject);
        txtBody = (EditText) view.findViewById(R.id.txtBody);
        btnSubmit = (Button) view.findViewById(R.id.btnSubmit);

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendEmail();
            }

            private void sendEmail() {
                Intent emailIntent = new Intent(Intent.ACTION_SEND);
                emailIntent.setType("text/plain");

                emailIntent.putExtra(Intent.EXTRA_EMAIL,
                        new String[]{"support@parking.com"});

                emailIntent.putExtra(Intent.EXTRA_SUBJECT,
                        txtSubject.getText().toString());
                emailIntent.putExtra(Intent.EXTRA_TEXT,
                        txtBody.getText().toString());

                emailIntent.setType("message/rfc822");

                startActivity(Intent.createChooser(emailIntent,
                        "Select Email Client"));
            }
        });
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_frag_feedback, container, false);



    }
}
