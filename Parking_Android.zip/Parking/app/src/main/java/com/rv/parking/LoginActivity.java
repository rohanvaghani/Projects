package com.rv.parking;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener{

    Button btnLogin,btnRegister;
    EditText editUsername, editPassword;
    DBHelper db;
    SQLiteDatabase thunderDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        btnLogin = (Button)findViewById(R.id.btnLogin);
        btnRegister = (Button)findViewById(R.id.btnRegister);
        editUsername = (EditText)findViewById(R.id.editUsername);
        editPassword = (EditText)findViewById(R.id.editPassword);

        btnLogin.setOnClickListener(this);
        btnRegister.setOnClickListener(this);

        db = new DBHelper(this);
    }

    @Override
    public void onClick(View view) {
        if(view.getId() == btnLogin.getId()) {
            String uname  = editUsername.getText().toString();
            String password = editPassword.getText().toString();
            if (verifyLogin()) {
                Intent homeIntent = new Intent(LoginActivity.this, HomeActivity.class);
                startActivity(homeIntent);
                finish();
            } else {
                Toast.makeText(LoginActivity.this, "Invalid Username or Password", Toast.LENGTH_LONG).show();
            }

        }
        else if(view.getId() == btnRegister.getId()) {
            Intent registerIntent = new Intent(LoginActivity.this, RegisterActivity.class);
            startActivity(registerIntent);
        }
    }

    private boolean verifyLogin(){
        try{
            thunderDB = db.getReadableDatabase();
            String columns[] = {"Email","Password"};

            Cursor cursor = thunderDB.query("UserInfo",columns,"Email = ? AND Password = ?",new String[]{editUsername.getText().toString(), editPassword.getText().toString()},null,null,null);

            if (cursor != null){
                if (cursor.getCount() > 0){
                    return true;
                }
            }

            return false;

        }catch (Exception e){
            Log.e("LoginActivity","Something went Wrong");
            return false;
        }finally {
            thunderDB.close();
        }



    }
}

