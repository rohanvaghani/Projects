package com.rv.parking;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class Frag_Userprofile extends Fragment {


    EditText name, email, password, contact, carplate;
    Button submit;


    DBHelper dbHelper;
    SQLiteDatabase thunderDB;


    @Override
    public void onViewCreated(View view,@Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        getActivity().setTitle("User Profile");
        name = (EditText) view.findViewById(R.id.txtName);
        email = (EditText) view.findViewById(R.id.txtEmail);
        password = (EditText) view.findViewById(R.id.txtPassword);
        contact = (EditText) view.findViewById(R.id.txtPhone);
        carplate = (EditText) view.findViewById(R.id.txtCarPlate);
        submit = (Button) view.findViewById(R.id.btnSubmit);



        try{
            dbHelper = new DBHelper(getActivity().getApplicationContext());
            thunderDB = dbHelper.getReadableDatabase();

            String us_email = email.getText().toString();


            String fetchdata_query = "SELECT * FROM UserInfo WHERE Email='" + TempValues.getCurrentLoggedUser() + "'";

            Cursor cursor = thunderDB.rawQuery(fetchdata_query, null);

            if(cursor.moveToFirst()){
                do{

                    name.setText(cursor.getString(1));
                    email.setText(cursor.getString(3));
                    password.setText(cursor.getString(4));
                    contact.setText(cursor.getString(2));
                    carplate.setText(cursor.getString(6));


                }while(cursor.moveToNext());
            }




        }catch (Exception e){
            Log.e("LoginActivity","Something went Wrong");

        }finally {
            thunderDB.close();
        }



        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                thunderDB = dbHelper.getWritableDatabase();


                ContentValues values = new ContentValues();
                values.put("Name", name.getText().toString());
                values.put("Phone", contact.getText().toString());
                values.put("Email", email.getText().toString());
                values.put("Password", password.getText().toString());
                values.put("carPlate", carplate.getText().toString());

                String[] whereArgs = {TempValues.currentLoggedUser};

                thunderDB.update("UserInfo", values, "Email = ?", whereArgs);

                TempValues.currentLoggedUser = email.getText().toString();

                Toast.makeText(getActivity(), "Data Updated!", Toast.LENGTH_SHORT).show();


            }
        });



    }






    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_frag__userprofile, container, false);
    }

}
