package com.rv.parking;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class ReportAdapter extends BaseAdapter {

    DBHelper dbHelper;
    SQLiteDatabase thunderDB;



    LayoutInflater inflater;
    Context context;

    ReportAdapter(Context context){
        inflater = (LayoutInflater.from(context));
    }




    @Override
    public int getCount() {
        return TempValues.total_records;
    }

    @Override
    public Object getItem(int i) {
        return i;
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {

        view = inflater.inflate(R.layout.list_view_data,null);

        TextView company = (TextView) view.findViewById(R.id.txtCarCompany);
        TextView amount = (TextView) view.findViewById(R.id.txtAmount);
        TextView lot = (TextView) view.findViewById(R.id.txtLotNumber);
        TextView spot = (TextView) view.findViewById(R.id.txtSpotNumber);
        TextView dateTime = (TextView) view.findViewById(R.id.txtDateTime);
        TextView carPlate = (TextView) view.findViewById(R.id.txtCarPlate);

        company.setText(TempValues.companies[i]);
        amount.setText(TempValues.amounts[i]);
        lot.setText(TempValues.lots[i]);
        spot.setText(TempValues.spots[i]);
        carPlate.setText(TempValues.carPlates[i]);
        dateTime.setText(TempValues.dateTimes[i]);

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(context,"item clicked ", Toast.LENGTH_LONG).show();
            }
        });



        return view;

    }
}
