package com.rv.parking;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

public class ReportActivity extends AppCompatActivity {

    DBHelper dbHelper;
    SQLiteDatabase thunderDB;

    ListView list_report;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);

        dbHelper = new DBHelper(getApplicationContext());
        thunderDB = dbHelper.getReadableDatabase();

        String selectQuery = "SELECT * FROM Parkings WHERE userEmail='" + TempValues.currentLoggedUser + "'";

        Cursor cursor = thunderDB.rawQuery(selectQuery, null);

        int index = 0;

        if(cursor.moveToFirst()){

            do{
                TempValues.carPlates[index] = cursor.getString(2).toString();
                TempValues.companies[index] = cursor.getString(3).toString();
                TempValues.amounts[index] = cursor.getString(9).toString();
                TempValues.spots[index] = cursor.getString(5).toString();
                TempValues.lots[index] = cursor.getString(6).toString();
                TempValues.dateTimes[index] = cursor.getString(8).toString();

                index = index + 1;


            }while(cursor.moveToNext());

        }

        TempValues.total_records = index;





        list_report = (ListView) findViewById(R.id.reportList);
        list_report.setAdapter(new ReportAdapter(getApplicationContext()));

    }
}
