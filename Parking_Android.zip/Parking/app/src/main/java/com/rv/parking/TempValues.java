package com.rv.parking;

public class TempValues {

    public static String currentLoggedUser = "";

    public static String carPlate = "", carCompany = "", totalHours = "", slot = "", lot = "", payment = "", dateTime = "", TotalCost = "";


    public static String[] carPlates = new String[40];
    public static String[] companies = new String[40];
    public static String[] amounts = new String[40];
    public static String[] lots = new String[40];
    public static String[] spots = new String[40];
    public static String[] dateTimes = new String[40];

    public static int total_records = 0;


    public static String getCarPlate() {
        return carPlate;
    }

    public static void setCarPlate(String carPlate) {
        TempValues.carPlate = carPlate;
    }

    public static String getCarCompany() {
        return carCompany;
    }

    public static void setCarCompany(String carCompany) {
        TempValues.carCompany = carCompany;
    }

    public static String getTotalHours() {
        return totalHours;
    }

    public static void setTotalHours(String totalHours) {
        TempValues.totalHours = totalHours;
    }

    public static String getSlot() {
        return slot;
    }

    public static void setSlot(String slot) {
        TempValues.slot = slot;
    }

    public static String getLot() {
        return lot;
    }

    public static void setLot(String lot) {
        TempValues.lot = lot;
    }

    public static String getPayment() {
        return payment;
    }

    public static void setPayment(String payment) {
        TempValues.payment = payment;
    }

    public static String getDateTime() {
        return dateTime;
    }

    public static void setDateTime(String dateTime) {
        TempValues.dateTime = dateTime;
    }

    public static String getTotalCost() {
        return TotalCost;
    }

    public static void setTotalCost(String totalCost) {
        TotalCost = totalCost;
    }

    public static String getCurrentLoggedUser() {
        return currentLoggedUser;
    }

    public static void setCurrentLoggedUser(String currentLoggedUser) {
        TempValues.currentLoggedUser = currentLoggedUser;
    }
}

