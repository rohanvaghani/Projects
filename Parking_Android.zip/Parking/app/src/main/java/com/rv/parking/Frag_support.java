package com.rv.parking;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;


public class Frag_support extends Fragment {

    ImageView btnCall, btnSms, btnMail;

    @Override
    public void onViewCreated(View view,@Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        getActivity().setTitle("Support Contact");

        btnCall = (ImageView) view.findViewById(R.id.btnCall);
        btnSms = (ImageView) view.findViewById(R.id.btnSms);
        btnMail = (ImageView) view.findViewById(R.id.btnMail);

        btnCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
     makeCall();
            }
        });


        btnSms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
sendSMS();
            }
        });

        btnMail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
sendEmail();
            }
        });

    }







    private void makeCall(){
        Intent callIntent = new Intent(Intent.ACTION_CALL);
        callIntent.setData(Uri.parse("tel:6479015616"));

        if (ActivityCompat.checkSelfPermission(getActivity().getApplicationContext(),
                Manifest.permission.CALL_PHONE) !=
                PackageManager.PERMISSION_GRANTED)
        {
            Toast.makeText(getActivity().getApplicationContext(),
                    "Call permission denied",Toast.LENGTH_LONG).show();
            return;
        }
        startActivity(callIntent);
    }

    private void sendEmail(){
        Intent emailIntent = new Intent(Intent.ACTION_SEND);
        emailIntent.setType("text/plain");

        emailIntent.putExtra(Intent.EXTRA_EMAIL,
                new String[]{"support@parking.com"});

        emailIntent.putExtra(Intent.EXTRA_SUBJECT,
                "Test Email");
        emailIntent.putExtra(Intent.EXTRA_TEXT,
                "This is a test message");

        emailIntent.setType("message/rfc822");

        startActivity(Intent.createChooser(emailIntent,
                "Select Email Client"));
    }

    private void sendSMS(){
        Intent smsIntent = new Intent(Intent.ACTION_SENDTO,
                Uri.parse("smsto:6479015616"));
        smsIntent.putExtra("sms_body", "Test message");

        if (ActivityCompat.checkSelfPermission(getActivity().getApplicationContext(),
                Manifest.permission.SEND_SMS) !=
                PackageManager.PERMISSION_GRANTED){
            Toast.makeText(getActivity().getApplicationContext(),
                    "SMS permission denied",Toast.LENGTH_LONG).show();
            return;
        }
        startActivity(smsIntent);
    }




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_frag_support, container, false);
    }
}
